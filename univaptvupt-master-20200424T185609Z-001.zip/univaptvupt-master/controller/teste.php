<?php

require_once("../model/PostTipo.php");

$postTipo = new PostTipo();
$postTipo->teste();